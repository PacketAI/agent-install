#!/bin/bash

BACKUP="/tmp/cloudwatch"

if [[ -d $BACKUP ]]; then
    rm -rf $BACKUP
fi
mkdir -p $BACKUP


for file in $(ls | grep -v -E 'lambda_function.py|install.sh|uninstall.sh|.python-version|requirements.txt|schemas.py|.envrc|lambda_function_test.py|README.md');do
    mv $file $BACKUP
done
