#!/bin/bash

pip3 install -t ./ -r requirements.txt
zip -r ecs.zip .
