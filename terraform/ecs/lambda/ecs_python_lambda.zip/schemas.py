import base64
import io
import gzip
import json
from marshmallow.utils import EXCLUDE
from marshmallow import Schema, fields, validate
from marshmallow.decorators import pre_load


def decode(data: str):
    return json.loads(
        gzip.GzipFile(fileobj=io.BytesIO(base64.b64decode(data, validate=True)))
        .read()
        .decode("utf-8")
    )


class Schema(Schema):
    class Meta:
        unknown = EXCLUDE


class MessageSchema(Schema):
    # Task definition
    container_instance_id = fields.String(data_key="ContainerInstanceId")
    cpu_utilized = fields.Float(data_key="CpuUtilized")
    cpu_reserved = fields.Float(data_key="CpuReserved")
    memory_reserved = fields.Float(data_key="MemoryReserved")  # Unit MegaBytes
    memory_utilized = fields.Float(data_key="MemoryUtilized")  # Unit MegaBytes
    ec2_instance_id = fields.String(data_key="EC2InstanceId")
    service_name = fields.String(data_key="ServiceName")
    task_id = fields.String(data_key="TaskId")
    task_definition_family = fields.String(data_key="TaskDefinitionFamily")
    task_definition_revision = fields.String(data_key="TaskDefinitionRevision")

    # network (Unit Bytes/second)
    network_rx_bytes = fields.Integer(data_key="NetworkRxBytes")
    network_rx_dropped = fields.Integer(data_key="NetworkRxDropped")
    network_rx_errors = fields.Integer(data_key="NetworkRxErrors")
    network_rx_packets = fields.Integer(data_key="NetworkRxPackets")
    network_tx_bytes = fields.Integer(data_key="NetworkTxBytes")
    network_tx_dropped = fields.Integer(data_key="NetworkTxDropped")
    network_tx_errors = fields.Integer(data_key="NetworkTxErrors")
    network_tx_packets = fields.Integer(data_key="NetworkTxPackets")
    # "NetworkRxDropped":0,"NetworkRxErrors":0,"NetworkRxPackets":125,"NetworkTxBytes":0,"NetworkTxDropped":0,"NetworkTxErrors":0,"NetworkTxPackets":

    # Container
    container_name = fields.String(data_key="ContainerName")
    storage_read_bytes = fields.Integer(data_key="StorageReadBytes")
    storage_write_bytes = fields.Integer(data_key="StorageWriteBytes")

    # Cluster
    cluster_name = fields.String(data_key="ClusterName")
    container_instance_count = fields.Integer(data_key="ContainerInstanceCount")
    service_count = fields.Integer(data_key="ServiceCount")
    task_count = fields.Integer(data_key="TaskCount")

    # Service
    desired_task_count = fields.Integer(data_key="DesiredTaskCount")
    running_task_count = fields.Integer(data_key="RunningTaskCount")
    pending_task_count = fields.Integer(data_key="PendingTaskCount")
    deployment_count = fields.Integer(data_key="DeploymentCount")
    task_set_count = fields.Integer(data_key="TaskSetCount")
    timestamp = fields.Integer(data_key="Timestamp")

    # Global
    type = fields.String(
        data_key="Type",
        validate=validate.OneOf(["Cluster", "Task", "Container", "Service"]),
    )


class LogEventSchema(Schema):
    id = fields.String()
    timestamp = fields.Integer()
    message = fields.Nested(MessageSchema)

    @pre_load
    def decode(self, data, **kwargs):
        data["message"] = json.loads(data["message"])
        return data


class DataSchema(Schema):
    message_type = fields.String(data_key="messageType")
    owner = fields.String()
    log_group = fields.String(data_key="logGroup")
    log_stream = fields.String(data_key="logStream")
    log_events = fields.Nested(LogEventSchema, many=True, data_key="logEvents")


class AwsLogsSchema(Schema):
    data = fields.Nested(DataSchema)

    @pre_load
    def decode_data(self, data, **kwargs):
        data["data"] = decode(data["data"])
        return data


class RawEventSchema(Schema):
    awslogs = fields.Nested(AwsLogsSchema)
