import base64
import io
import gzip
from schemas import RawEventSchema
import requests
import os

infra_id = os.environ["INFRA_ID"]
ingest_url = os.environ["INGEST_URL"]


def lambda_handler(event, context):

    schema = RawEventSchema()
    result = schema.load(event)
    cluster_name_set = set()
    for event in result["awslogs"]["data"]["log_events"]:
        cluster_name = event["message"]["cluster_name"]
        if not cluster_name:
            continue
        cluster_name_set.add(cluster_name)
    if len(cluster_name_set) != 1:
        raise Exception(f"Invalid data. Multiple cluster name:{cluster_name_set}")
    cluster_name = cluster_name_set.pop()

    response = requests.post(f"{ingest_url}/aws/ecs/{infra_id}/{cluster_name}", json=result)
    if response.status_code != 200:
        raise Exception(f"Invalid status code: {response.status_code}")

