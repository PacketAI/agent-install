from lambda_function import lambda_handler

def test_lambda_handler():
    class Msg:
        def __init__(self, event, context=None):
            self.event = event
            self.context = context

    msgs = [
        Msg(
            event={
                "awslogs": {
                    "data": "H4sIAAAAAAAAAIVSXW+cMBD8L36+CsyHgXs7kUvUh1RVubYPAVUObDirYCPbJEKn++9d4C5KoNIhHmA8s7sz3hNpwRhew2HogGzJ3e6w+/O4z7Ldw55siHqToBGOWBQkcRi7Yegi3Kj6Qau+wxOHvxkHSuOUSloukC6kEfXRGseCsbsapHU60C9Kt1yWMKszq4G3KM9Av4oSDtBAC1YPX1ola1U9mxlHtumfTalFZ4WS96KxoA3ZPpF26AZ7xJ7YhBRT0f0r9hoPT0RUWNtnLvMSGtM48gPmxzQIXM+PkpD5SRT7CXNp6CYe810aMc8PAjQY0MTDplZgLJa36JAyGlF8YxefzTUuLH/KyS8cBsfKyTYnbk42ORljnH4vxibw8v2Nt/PZZ48TJW16g9beKe/ZzVWv4+TLeXJyB0ZoqA7c/E1VPwq2PsI/eimFrJfwd5DVAp6LdI0aWux3RenYFlkZ2I/EtFF99Zvb8viI1yVKk49552Qc3HS8nKffp5mTXvfh62UfJidr1SRYm0DuTynsdHqBzpuPkrXBm5K1+ZuSVTA3FZ9D+x+9GAPHG5Xj7kxRPC12ZLkQRXEuzig8/wP4qUFlrwMAAA=="
                }
            }
        ),
        Msg(
            event={
                "awslogs": {
                    "data": "H4sIAAAAAAAAAIVSwW6jMBD9F5+zAkOAkltEs1UPXa2WbPdQo5ULs8Qq2Mg2rVCUf+8YkqqFlcIJ3rw3M+8xR9KCMbyG/dAB2ZDb7X7792GX59u7HVkR9SZBI5zEyTq9iW78KPIRblR9p1XfYcXjb8aD0nilkpYLpAtpRH2wxrNg7LYGab0O9D+lWy5LmNS51cBblOegX0UJe2igBauHb62StaqezYQj2/TPptSis0LJ76KxoA3ZPJF26AZ7wJk4hBRj090rznLFIxEV9g5jPw5SmkZBFKbUT8MwCvwkCtfrNA4QpDRI/DQIHMEZ9JMgoWkY41ArMBbLW3RIY5pQmgRrH5/VJS5sf2TkEZfBtRjZMOIzsmLExTh+no2N4Pn9B2+n2lePIyVreoPWPigf2U1dL+uw+T6M3IIRGqo9Ny+Z6p1gEyL8q5dSyHoO/wRZzeCpSdeoocV5F5S6scjKwX4mZo3qqz/clocH/F2iNMzlzYhb3HS8nLbfZbmXXe7h/nwPo5OlahQsTSD3txR2rJ6h0+qzZGnwqmRp/qpkEcxVxdfQ/kcvXOD4R6W7nTGKp9mNzA+iKE7FCYWnd2NNGLGvAwAA"
                }
            }
        ),
        Msg(
            event={
                "awslogs": {
                    "data": "H4sIAAAAAAAAAIVRXW+CMBT9L312obS0gG9EndmDe8FtD0KWDjttJoW0RWOM/30XUOfclvEE5+Pecw8HVEprxUrO97VEQzRO5snrbJKmyXSCBqjaaWkADnkYxBGLMGMY4E21mpqqqYHxxM56srBeUWknFMiVtmq1dtZz0rpkJbXzamneK1MKXcjenTojRQn20aaxTpq53MhSOrO/u5hAaJs3WxhVO1Xpe7UBnUXDBSr39d6tYR1IUd7Nm2zB0ZIHpJYwlnLMSezHjDAa+zimlBEcMhoEMScsYJxyhnEYRxz7mFAS08jnESWw1CloxIkSjvO5H/p+SAIMz+DcFIw/ZOgZwkCsDA0zhDM0yFDbYPd5uqkDT++Pouy5y3m95bwru10GnLAfo6pplUPeTjr3+6DBAk2eSQpkKs1WfUGk21w1yxfhivUMilWFzdp6MtRGsbUo+jyTUepdT+7+XJftp6szXMUC0ZNWrr+5h46Da+1fkf81fj/nN3kO4Bja0+1P6EIubsrO82N+BOHxE/dvYqHjAgAA"
                }
            }
        ),
    ]
    for msg in msgs:
        lambda_handler(msg.event, "world")

if __name__ == "__main__":
    test_lambda_handler()

